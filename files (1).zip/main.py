#!/usr/bin/env python3
"""
main.py
-------
DackNet-AI — DackNet-Ops Cybersecurity Assistant

Entry point for the program. Flow:
  1. Show the banner.
  2. Ask for the login password (checked against a SHA-256 hash — see
     config.py). This gates who can start the program at all.
  3. Ask for the user's own OpenRouter API key (get one free at
     https://openrouter.ai/keys). Optionally save it to a local .env file
     so it doesn't need to be re-entered every run.
  4. Drop into a real-time chat loop that streams answers about
     cybersecurity and DackNet-Ops projects.

Run it with:
    python main.py
"""

import os
import sys
import getpass

from dotenv import load_dotenv, set_key

import config
import ui
from knowledge_base import SYSTEM_PROMPT
from openrouter_client import stream_chat_completion, OpenRouterError


def login() -> bool:
    """Prompt for the login password up to 3 times. Return True if it matches."""
    for attempt in range(3):
        password = getpass.getpass("Enter DackNet-AI login password: ")
        if config.verify_password(password):
            ui.print_success("Login successful. Welcome back, operator.")
            return True
        ui.print_error(f"Incorrect password. {2 - attempt} attempt(s) remaining.")
    return False


def get_api_key() -> str:
    """
    Get the user's OpenRouter API key: first check a saved .env file, then
    fall back to prompting for it (with the option to save it for next time).
    """
    load_dotenv(config.ENV_FILE)
    existing_key = os.getenv("OPENROUTER_API_KEY")

    if existing_key:
        ui.print_system("Using saved OpenRouter API key from .env")
        return existing_key

    ui.print_system(
        "No saved API key found. Get a free key at https://openrouter.ai/keys"
    )
    api_key = getpass.getpass("Enter your OpenRouter API key: ").strip()

    if not api_key:
        ui.print_error("An OpenRouter API key is required to run DackNet-AI.")
        sys.exit(1)

    save_choice = ui.console.input(
        "Save this key locally in .env so you don't re-enter it next time? [y/N]: "
    ).strip().lower()

    if save_choice == "y":
        # set_key creates the .env file if it doesn't exist yet.
        set_key(config.ENV_FILE, "OPENROUTER_API_KEY", api_key)
        ui.print_success(f"Saved to {config.ENV_FILE} (make sure this file is git-ignored!)")

    return api_key


def chat_loop(api_key: str) -> None:
    """The main real-time conversation loop."""
    conversation = [{"role": "system", "content": SYSTEM_PROMPT}]

    ui.print_system("Type your question, or /help for commands.")

    while True:
        try:
            user_input = ui.print_user_prompt().strip()
        except (EOFError, KeyboardInterrupt):
            print()
            ui.print_system("Session ended. Stay secure.")
            break

        if not user_input:
            continue

        # ---- slash commands -------------------------------------------------
        if user_input == "/exit":
            ui.print_system("Goodbye, operator.")
            break
        if user_input == "/help":
            ui.print_help()
            continue
        if user_input == "/about":
            ui.console.print(
                f"[bold green]{config.APP_NAME}[/bold green] v{config.APP_VERSION} — "
                f"{config.APP_TAGLINE}\nBuilt by {config.AUTHOR}\n"
                f"{config.GITHUB_PROFILE} | {config.CONTACT_EMAIL}"
            )
            continue
        if user_input == "/projects":
            conversation.append({"role": "user", "content": "List the DackNet-Ops projects."})
        elif user_input == "/clear":
            conversation = [{"role": "system", "content": SYSTEM_PROMPT}]
            ui.print_success("Conversation history cleared.")
            continue
        else:
            conversation.append({"role": "user", "content": user_input})

        # ---- get a real-time streamed reply ---------------------------------
        ui.start_ai_line()
        full_reply = ""
        try:
            for chunk in stream_chat_completion(api_key, conversation):
                ui.stream_chunk(chunk)
                full_reply += chunk
        except OpenRouterError as exc:
            ui.end_ai_line()
            ui.print_error(str(exc))
            conversation.pop()  # don't keep a failed turn in history
            continue

        ui.end_ai_line()
        conversation.append({"role": "assistant", "content": full_reply})


def main() -> None:
    ui.show_banner()

    if not login():
        ui.print_error("Too many failed attempts. Exiting.")
        sys.exit(1)

    api_key = get_api_key()
    chat_loop(api_key)


if __name__ == "__main__":
    main()
