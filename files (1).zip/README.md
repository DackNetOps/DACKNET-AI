# DackNet-AI

**DackNet-Ops Cybersecurity Assistant** — a terminal-based AI agent that answers
cybersecurity questions in real time and knows about the DackNet-Ops project
ecosystem.

Built by [Owen Kadzuwa](https://dacknetops.github.io) (DackNet-Ops).

---

## Features

- 🔐 **Login-gated** — password checked against a SHA-256 hash (no plaintext
  password anywhere in the source, safe to publish on GitHub).
- 🔑 **Bring your own OpenRouter API key** — every user supplies their own
  key at [openrouter.ai/keys](https://openrouter.ai/keys); no key ever
  ships with this repo.
- ⚡ **Real-time streaming responses** — replies stream token-by-token like
  a live conversation, not a single blocking reply.
- 🛡️ **Cybersecurity-focused** — explains networking, ethical hacking
  concepts, secure coding, tools (nmap, Wireshark, Burp Suite...), and
  defensive best practices. Refuses to give actionable attack instructions
  against systems you don't own.
- 🧩 **Knows DackNet-Ops** — ask it about the DackNet-Ops AI Assistant,
  Logcat Analyzer, PCAP Analyzer, mobile app, or Apexwix Laptops.
- 🧱 **Modular, heavily commented code** — split into `config.py`,
  `knowledge_base.py`, `openrouter_client.py`, `ui.py`, and `main.py` so
  it's easy to read, learn from, and extend.

## Setup

```bash
git clone https://github.com/<your-username>/DackNet-AI.git
cd DackNet-AI
pip install -r requirements.txt
python main.py
```

1. When prompted, enter the login password.
2. When prompted, enter your own OpenRouter API key (get a free one at
   https://openrouter.ai/keys). You can choose to save it locally in a
   `.env` file (already git-ignored) so you don't have to re-enter it.
3. Start chatting. Try:
   - `what is a man-in-the-middle attack?`
   - `/projects`
   - `/about`
   - `/help`

## Changing the login password

The real password is never stored in the code — only its SHA-256 hash is.
To set your own password before publishing your fork:

```bash
python3 -c "import hashlib; print(hashlib.sha256(b'your-new-password').hexdigest())"
```

Paste the resulting hash into `LOGIN_PASSWORD_HASH` in `config.py`.

## Changing the AI model

OpenRouter supports many models. Edit `DEFAULT_MODEL` in `config.py` to any
model ID listed at [openrouter.ai/models](https://openrouter.ai/models)
(free-tier models are marked `:free`).

## Project structure

```
DackNet-AI/
├── main.py               # entry point: login, API key setup, chat loop
├── config.py              # app constants, password hash, model settings
├── knowledge_base.py      # system prompt + DackNet-Ops background facts
├── openrouter_client.py   # streaming OpenRouter API client
├── ui.py                  # terminal banner + rich-based styling
├── requirements.txt
├── .env.example
└── .gitignore
```

## Security notes

- The `.env` file (if you create one) holds your real API key — it's
  already listed in `.gitignore` so it won't be committed by accident.
  Double-check before pushing.
- Never commit a real OpenRouter API key or a plaintext password to a
  public repository.

## License

MIT — free to use, modify, and build on.
