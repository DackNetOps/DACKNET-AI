"""
config.py
---------
Central configuration for DackNet-AI.

Keeping all constants in one place makes the rest of the codebase easier
to read and easier to modify later (e.g. swapping the OpenRouter model,
changing the app name, or rotating the login password).
"""

import hashlib

# --------------------------------------------------------------------------
# APP METADATA
# --------------------------------------------------------------------------
APP_NAME = "DackNet-AI"
APP_TAGLINE = "DackNet-Ops Cybersecurity Assistant"
APP_VERSION = "1.0.0"
AUTHOR = "Owen Kadzuwa (DackNet-Ops)"
GITHUB_PROFILE = "https://dacknetops.github.io"
CONTACT_EMAIL = "dacknet4631@gmail.com"

# --------------------------------------------------------------------------
# LOGIN PASSWORD
# --------------------------------------------------------------------------
# We NEVER store the real password in plaintext inside the source code,
# because this project is meant to be published on GitHub. Instead we store
# only its SHA-256 hash, and compare hashes at login time. This means the
# real password is never visible to anyone reading the repository.
#
# The hash below corresponds to the password: dacknet@4631
# If you want to change the password, generate a new hash with:
#   python3 -c "import hashlib; print(hashlib.sha256(b'your-new-password').hexdigest())"
# and paste the result below.
LOGIN_PASSWORD_HASH = "5e759425e457c985df5c225bd6eff0718e8bc1441dd82814fe5a240e7146a8bb"


def verify_password(attempt: str) -> bool:
    """
    Hash the user's password attempt and compare it against the stored hash.
    Returns True if it matches, False otherwise.
    """
    attempt_hash = hashlib.sha256(attempt.encode("utf-8")).hexdigest()
    return attempt_hash == LOGIN_PASSWORD_HASH


# --------------------------------------------------------------------------
# OPENROUTER (AI MODEL) SETTINGS
# --------------------------------------------------------------------------
# OpenRouter (https://openrouter.ai) gives access to many different AI
# models through a single, OpenAI-compatible API. Each user who clones this
# repo supplies their OWN OpenRouter API key — the program never ships with
# a key baked in, and no key is ever committed to GitHub.
OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"

# Default model. You can change this to any model listed at
# https://openrouter.ai/models — free-tier models are marked ":free".
DEFAULT_MODEL = "openai/gpt-oss-20b:free"

# Used by OpenRouter for its own leaderboard/analytics — safe to leave as-is.
HTTP_REFERER = "https://dacknetops.github.io"
X_TITLE = "DackNet-AI"

# --------------------------------------------------------------------------
# LOCAL STORAGE
# --------------------------------------------------------------------------
ENV_FILE = ".env"          # where a saved API key lives, if the user opts in
HISTORY_FILE = ".dacknet_history.json"  # optional saved chat history
