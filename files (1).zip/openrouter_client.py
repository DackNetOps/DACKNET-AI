"""
openrouter_client.py
---------------------
Handles all communication with the OpenRouter API (https://openrouter.ai).

OpenRouter exposes an OpenAI-compatible /chat/completions endpoint that can
route requests to many different underlying models using one API key. This
module streams the response token-by-token so DackNet-AI feels like a
real-time conversation instead of waiting for one big reply.
"""

import json
import requests

from config import OPENROUTER_API_URL, HTTP_REFERER, X_TITLE, DEFAULT_MODEL


class OpenRouterError(Exception):
    """Raised when OpenRouter returns an error or an unexpected response."""
    pass


def stream_chat_completion(api_key: str, messages: list, model: str = DEFAULT_MODEL):
    """
    Send a chat completion request to OpenRouter and yield text chunks as
    they arrive, so the caller can print them in real time.

    Parameters
    ----------
    api_key : str
        The user's own OpenRouter API key (never hardcoded, never logged).
    messages : list[dict]
        Standard OpenAI-style message list: [{"role": "...", "content": "..."}]
    model : str
        Which model on OpenRouter to use.

    Yields
    ------
    str
        Successive pieces of the assistant's reply.
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        # These two headers are optional but recommended by OpenRouter for
        # analytics/attribution — they don't affect functionality.
        "HTTP-Referer": HTTP_REFERER,
        "X-Title": X_TITLE,
    }

    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
    }

    try:
        response = requests.post(
            OPENROUTER_API_URL,
            headers=headers,
            json=payload,
            stream=True,
            timeout=60,
        )
    except requests.exceptions.RequestException as exc:
        raise OpenRouterError(f"Network error contacting OpenRouter: {exc}") from exc

    if response.status_code == 401:
        raise OpenRouterError("Invalid OpenRouter API key (401 Unauthorized).")
    if response.status_code != 200:
        raise OpenRouterError(
            f"OpenRouter returned status {response.status_code}: {response.text[:300]}"
        )

    # OpenRouter streams Server-Sent Events: lines like "data: {...}" ending
    # in "data: [DONE]". We parse each line and pull out the text delta.
    for raw_line in response.iter_lines(decode_unicode=True):
        if not raw_line:
            continue
        if not raw_line.startswith("data: "):
            continue

        data_str = raw_line[len("data: "):].strip()
        if data_str == "[DONE]":
            break

        try:
            data = json.loads(data_str)
        except json.JSONDecodeError:
            continue  # skip malformed/keep-alive lines

        choices = data.get("choices", [])
        if not choices:
            continue

        delta = choices[0].get("delta", {})
        content = delta.get("content")
        if content:
            yield content
