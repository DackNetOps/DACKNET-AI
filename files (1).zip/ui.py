"""
ui.py
-----
All terminal presentation lives here: the startup banner, colored text
helpers, and small formatting utilities. Keeping this separate from
main.py means you can restyle the whole app (colors, banner, layout)
without touching the login or chat logic.

Uses the `rich` library for cyberpunk-style green-on-black terminal output,
matching the aesthetic of the other DackNet-Ops tools.
"""

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.markdown import Markdown

console = Console()

# ASCII banner placeholder.
# NOTE: A terminal app can't render a bitmap image directly, so this is a
# text-art stand-in for the DackNet-AI logo. If you send over the actual
# logo image, it can be converted into ASCII/ANSI art (e.g. with a tool
# like `chafa` or `jp2a`) and swapped in here — or the raw image file can
# ship alongside the repo for use in the README / GitHub page instead.
BANNER = r"""
 ____             _    _   _      _        _    ___
|  _ \  __ _  ___| | _| \ | | ___| |_     / \  |_ _|
| | | |/ _` |/ __| |/ /  \| |/ _ \ __|   / _ \  | |
| |_| | (_| | (__|   <| |\  |  __/ |_   / ___ \ | |
|____/ \__,_|\___|_|\_\_| \_|\___|\__| /_/   \_\___|
"""


def show_banner() -> None:
    """Print the startup banner and tagline in the DackNet-Ops green theme."""
    console.print(Text(BANNER, style="bold green"))
    console.print(
        Panel.fit(
            "[bold green]DackNet-AI[/bold green] — [green]DackNet-Ops Cybersecurity Assistant[/green]\n"
            "[dim]github: dacknetops.github.io   |   contact: dacknet4631@gmail.com[/dim]",
            border_style="green",
        )
    )


def print_system(message: str) -> None:
    """Print a system/status message (login prompts, errors, notices)."""
    console.print(f"[bold cyan][system][/bold cyan] {message}")


def print_error(message: str) -> None:
    console.print(f"[bold red][error][/bold red] {message}")


def print_success(message: str) -> None:
    console.print(f"[bold green][ok][/bold green] {message}")


def print_user_prompt() -> str:
    """Display the 'you' prompt and return whatever the user types."""
    return console.input("[bold white]you[/bold white] [dim]>[/dim] ")


def start_ai_line() -> None:
    console.print("[bold green]DackNet-AI[/bold green] [dim]>[/dim] ", end="")


def stream_chunk(chunk: str) -> None:
    """Print a piece of streamed AI output without a trailing newline."""
    console.print(chunk, end="", soft_wrap=True)


def end_ai_line() -> None:
    console.print()  # newline after the streamed response finishes


def print_help() -> None:
    help_text = """
**Available commands**

- `/help`      — show this help message
- `/about`     — learn about DackNet-AI and DackNet-Ops
- `/projects`  — list DackNet-Ops projects
- `/clear`     — clear the conversation history (keeps you logged in)
- `/exit`      — quit DackNet-AI

Otherwise, just type a question — about cybersecurity, ethical hacking,
networking, or DackNet-Ops — and DackNet-AI will respond in real time.
"""
    console.print(Markdown(help_text))
